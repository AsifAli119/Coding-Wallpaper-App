part of 'detial_bloc.dart';

@immutable
abstract class DetialState {}

class DetialInitial extends DetialState {}
class IsSavedImageState extends DetialState{
  SavedImagesToGallery savedImagesToGallery;
  IsSavedImageState({required this.savedImagesToGallery});
}